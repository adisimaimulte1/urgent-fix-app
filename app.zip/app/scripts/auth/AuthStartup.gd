extends Control

const FIREBASE_AUTH_GATE_SCRIPT := preload("res://app/scripts/firebase/FirebaseAuthGate.gd")
const FIREBASE_AUTH_SERVICE_SCRIPT := preload("res://app/scripts/firebase/FirebaseAuthService.gd")
const UF_LOADING_SPINNER_SCRIPT := preload("res://app/scripts/ui/UFLoadingSpinner.gd")
const MAIN_APP_SCENE_PATH := "res://app/scenes/Main.tscn"

var _auth_gate: Control
var _auth_service: Node
var _app_font: Font
var _scale := 1.0
var _current_profile: Dictionary = {}
var _pending_auth_profile: Dictionary = {}
var _auth_busy := false
var _loading_overlay: Control

func _enter_tree() -> void:
	RenderingServer.set_default_clear_color(Color.WHITE)

func _ready() -> void:
	_load_font_if_available()
	_compute_scale()
	_show_auth_gate()

func _notification(what: int) -> void:
	if what == NOTIFICATION_RESIZED:
		_compute_scale()
		if is_instance_valid(_auth_gate) and _auth_gate.has_method("setup"):
			_auth_gate.call("setup", _scale, _app_font)

func _compute_scale() -> void:
	var viewport_size := get_viewport_rect().size
	if viewport_size.x <= 0.0 or viewport_size.y <= 0.0:
		_scale = 1.0
		return
	var raw_scale := minf(viewport_size.x / 390.0, viewport_size.y / 844.0)
	_scale = clampf(raw_scale, 0.86, 2.65)

func _load_font_if_available() -> void:
	var system_font := SystemFont.new()
	system_font.font_names = PackedStringArray(["Arial", "Roboto", "Noto Sans", "Helvetica", "Sans Serif"])
	system_font.font_weight = 800
	system_font.allow_system_fallback = true
	_app_font = system_font

func _show_auth_gate() -> void:
	_clear_children()

	_auth_service = FIREBASE_AUTH_SERVICE_SCRIPT.new()
	_auth_service.name = "FirebaseAuthService"
	add_child(_auth_service)
	_auth_service.auth_started.connect(_on_auth_started)
	_auth_service.auth_succeeded.connect(_on_auth_succeeded)
	_auth_service.auth_failed.connect(_on_auth_failed)
	_auth_service.signed_out.connect(_on_signed_out)

	_auth_gate = FIREBASE_AUTH_GATE_SCRIPT.new()
	_auth_gate.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(_auth_gate)
	_auth_gate.login_requested.connect(_on_login_requested)
	_auth_gate.register_requested.connect(_on_register_requested)

	if _auth_gate.has_method("setup"):
		_auth_gate.call("setup", _scale, _app_font)

	call_deferred("_restore_existing_session_if_valid")

func _restore_existing_session_if_valid() -> void:
	if not is_instance_valid(_auth_service):
		return
	if _auth_service.has_method("is_signed_in") and bool(_auth_service.call("is_signed_in")):
		var profile := {
			"uid": str(_auth_service.call("uid")),
			"email": str(_auth_service.call("email")),
			"account_type": "client",
			"auth_mode": "session",
			"id_token": str(_auth_service.call("id_token"))
		}
		_on_authenticated(profile)

func _on_login_requested(email: String, password: String, account_type: String) -> void:
	if _auth_busy:
		return
	_pending_auth_profile = {
		"email": email.strip_edges(),
		"account_type": _normalize_account_type(account_type),
		"auth_mode": "login"
	}
	_set_gate_status("", false)
	_show_loading_overlay()
	_auth_service.sign_in(email, password)

func _on_register_requested(email: String, password: String, account_type: String, profile_data: Dictionary) -> void:
	if _auth_busy:
		return
	_pending_auth_profile = profile_data.duplicate(true)
	_pending_auth_profile["email"] = email.strip_edges()
	_pending_auth_profile["account_type"] = _normalize_account_type(account_type)
	_pending_auth_profile["auth_mode"] = "register"
	_pending_auth_profile["created_at"] = Time.get_datetime_string_from_system()
	_set_gate_status("", false)
	_show_loading_overlay()
	_auth_service.sign_up(email, password)

func _on_auth_started() -> void:
	_auth_busy = true
	_show_loading_overlay()

func _on_auth_succeeded(user: Dictionary) -> void:
	_auth_busy = false
	var profile := _pending_auth_profile.duplicate(true)
	profile["uid"] = str(user.get("localId", ""))
	profile["email"] = str(user.get("email", profile.get("email", "")))
	profile["id_token"] = str(user.get("idToken", ""))
	if not profile.has("account_type") or str(profile.get("account_type", "")).strip_edges() == "":
		profile["account_type"] = "client"
	_set_gate_status("", false)
	_show_loading_overlay()
	call_deferred("_on_authenticated", profile)

func _on_auth_failed(message: String) -> void:
	_auth_busy = false
	_hide_loading_overlay()
	_set_gate_status(message, true)

func _on_signed_out() -> void:
	_auth_busy = false
	_hide_loading_overlay()
	_pending_auth_profile.clear()
	_show_auth_gate()


func _show_loading_overlay() -> void:
	if is_instance_valid(_loading_overlay):
		_loading_overlay.move_to_front()
		return

	_loading_overlay = Control.new()
	_loading_overlay.name = "AuthLoadingOverlay"
	_loading_overlay.set_anchors_preset(Control.PRESET_FULL_RECT)
	_loading_overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	_loading_overlay.z_index = 4096
	add_child(_loading_overlay)

	var dim := ColorRect.new()
	dim.color = Color(1, 1, 1, 0.28)
	dim.set_anchors_preset(Control.PRESET_FULL_RECT)
	dim.mouse_filter = Control.MOUSE_FILTER_STOP
	_loading_overlay.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_loading_overlay.add_child(center)

	var bubble := PanelContainer.new()
	bubble.custom_minimum_size = Vector2(86, 86)
	bubble.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	bubble.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	bubble.add_theme_stylebox_override("panel", _loading_style())
	center.add_child(bubble)

	var spinner_holder := CenterContainer.new()
	spinner_holder.set_anchors_preset(Control.PRESET_FULL_RECT)
	spinner_holder.mouse_filter = Control.MOUSE_FILTER_IGNORE
	bubble.add_child(spinner_holder)

	var spinner := UF_LOADING_SPINNER_SCRIPT.new()
	spinner.custom_minimum_size = Vector2(48, 48)
	spinner_holder.add_child(spinner)

	bubble.scale = Vector2(0.88, 0.88)
	bubble.modulate.a = 0.0
	var tween := create_tween()
	tween.set_parallel(true)
	tween.tween_property(bubble, "scale", Vector2.ONE, 0.22).set_trans(Tween.TRANS_BACK).set_ease(Tween.EASE_OUT)
	tween.tween_property(bubble, "modulate:a", 1.0, 0.16).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_OUT)

func _hide_loading_overlay() -> void:
	if not is_instance_valid(_loading_overlay):
		_loading_overlay = null
		return
	_loading_overlay.queue_free()
	_loading_overlay = null

func _loading_style() -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = Color(1, 1, 1, 0.94)
	style.border_color = Color("#02286E")
	style.set_border_width_all(2)
	style.set_corner_radius_all(28)
	style.shadow_color = Color(0, 0, 0, 0.16)
	style.shadow_size = 18
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	return style

func _normalize_account_type(value: String) -> String:
	var cleaned := value.strip_edges().to_lower()
	match cleaned:
		"user", "client", "customer":
			return "client"
		"company", "firma", "firmă", "provider":
			return "company"
		_:
			return "client"

func _set_gate_status(text: String, is_error: bool) -> void:
	if is_instance_valid(_auth_gate) and _auth_gate.has_method("set_status"):
		_auth_gate.call("set_status", text, is_error)

func _on_authenticated(profile: Dictionary) -> void:
	_current_profile = profile.duplicate(true)
	_load_main_app()

func _load_main_app() -> void:
	_clear_children()

	var packed_scene := load(MAIN_APP_SCENE_PATH)
	if not (packed_scene is PackedScene):
		packed_scene = load("res://app/scenes/MainApp.tscn")
	if not (packed_scene is PackedScene):
		push_error("Main app scene not found at: " + MAIN_APP_SCENE_PATH)
		return

	var main_app: Node = packed_scene.instantiate()
	add_child(main_app)

	if main_app.has_method("set_auth_profile"):
		main_app.call("set_auth_profile", _current_profile)
	elif main_app.has_method("set_account_profile"):
		main_app.call("set_account_profile", _current_profile)
	else:
		main_app.set_meta("auth_profile", _current_profile)
		main_app.set_meta("account_type", str(_current_profile.get("account_type", "client")))

func _clear_children() -> void:
	for child in get_children():
		child.queue_free()
	_loading_overlay = null
