extends Node

signal auth_started
signal auth_succeeded(user: Dictionary)
signal auth_failed(message: String)
signal signed_out

const FirebaseConfig := preload("res://app/scripts/firebase/FirebaseConfig.gd")
const SESSION_PATH := "user://urgentfix_firebase_session.json"

var _http: HTTPRequest
var current_user: Dictionary = {}
var _pending_mode := ""
var last_auth_mode := ""

func _ready() -> void:
	_http = HTTPRequest.new()
	_http.timeout = 20.0
	add_child(_http)
	_http.request_completed.connect(_on_request_completed)
	_load_session()

func is_signed_in() -> bool:
	return not current_user.is_empty() and str(current_user.get("idToken", "")) != "" and str(current_user.get("localId", "")) != ""

func id_token() -> String:
	return str(current_user.get("idToken", ""))

func uid() -> String:
	return str(current_user.get("localId", ""))

func email() -> String:
	return str(current_user.get("email", ""))

func sign_up(email_value: String, password_value: String) -> void:
	_send_auth_request("signup", FirebaseConfig.AUTH_SIGN_UP_URL % FirebaseConfig.API_KEY, email_value, password_value)

func sign_in(email_value: String, password_value: String) -> void:
	_send_auth_request("signin", FirebaseConfig.AUTH_SIGN_IN_URL % FirebaseConfig.API_KEY, email_value, password_value)

func sign_out() -> void:
	current_user.clear()
	last_auth_mode = ""
	if FileAccess.file_exists(SESSION_PATH):
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SESSION_PATH))
	signed_out.emit()

func _send_auth_request(mode: String, url: String, email_value: String, password_value: String) -> void:
	if _http == null:
		auth_failed.emit("Serviciul Firebase Auth nu este inițializat.")
		return
	if not FirebaseConfig.is_configured():
		auth_failed.emit("FirebaseConfig.gd nu este completat cu API_KEY și PROJECT_ID.")
		return
	if email_value.strip_edges() == "" or password_value.length() < 6:
		auth_failed.emit("Email invalid sau parolă prea scurtă. Firebase cere minim 6 caractere.")
		return
	if _http.get_http_client_status() != HTTPClient.STATUS_DISCONNECTED:
		auth_failed.emit("Există deja o cerere de autentificare în curs.")
		return
	_pending_mode = mode
	auth_started.emit()
	var body := JSON.stringify({"email": email_value.strip_edges(), "password": password_value, "returnSecureToken": true})
	var err := _http.request(url, ["Content-Type: application/json"], HTTPClient.METHOD_POST, body)
	if err != OK:
		auth_failed.emit("Nu am putut porni cererea Firebase: %s" % str(err))

func _on_request_completed(result: int, response_code: int, _headers: PackedStringArray, body: PackedByteArray) -> void:
	if result != HTTPRequest.RESULT_SUCCESS:
		auth_failed.emit("Conexiunea către Firebase a eșuat. Verifică internetul și încearcă din nou.")
		return
	var raw := body.get_string_from_utf8()
	var parsed: Variant = JSON.parse_string(raw)
	if response_code < 200 or response_code >= 300:
		auth_failed.emit(_friendly_auth_error(parsed, response_code))
		return
	if not (parsed is Dictionary):
		auth_failed.emit("Răspuns Firebase invalid.")
		return
	last_auth_mode = _pending_mode
	current_user = parsed.duplicate(true)
	_save_session()
	auth_succeeded.emit(current_user)

func _friendly_auth_error(parsed: Variant, response_code: int = 0) -> String:
	var code := "UNKNOWN_ERROR"
	if parsed is Dictionary:
		var error_data: Variant = parsed.get("error", {})
		if error_data is Dictionary:
			code = str(error_data.get("message", code))
	match code:
		"EMAIL_EXISTS": return "Există deja un cont cu emailul acesta."
		"EMAIL_NOT_FOUND", "INVALID_LOGIN_CREDENTIALS": return "Emailul sau parola nu sunt corecte."
		"INVALID_PASSWORD": return "Parola nu este corectă."
		"USER_DISABLED": return "Contul este dezactivat în Firebase."
		"INVALID_EMAIL": return "Emailul nu este valid."
		"WEAK_PASSWORD : Password should be at least 6 characters", "WEAK_PASSWORD": return "Parola trebuie să aibă cel puțin 6 caractere."
		"TOO_MANY_ATTEMPTS_TRY_LATER": return "Prea multe încercări. Încearcă din nou puțin mai târziu."
		_:
			if response_code == 0:
				return "Firebase Auth: %s" % code
			return "Firebase Auth %d: %s" % [response_code, code]

func _save_session() -> void:
	var file := FileAccess.open(SESSION_PATH, FileAccess.WRITE)
	if file != null:
		file.store_string(JSON.stringify(current_user, "\t"))

func _load_session() -> void:
	if not FileAccess.file_exists(SESSION_PATH):
		return
	var file := FileAccess.open(SESSION_PATH, FileAccess.READ)
	if file == null:
		return
	var parsed: Variant = JSON.parse_string(file.get_as_text())
	if parsed is Dictionary and str(parsed.get("idToken", "")) != "":
		current_user = parsed.duplicate(true)
		last_auth_mode = "session"
